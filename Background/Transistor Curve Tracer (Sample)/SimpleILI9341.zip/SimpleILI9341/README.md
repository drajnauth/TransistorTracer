# SimpleILI9341

This is a standalone library that contains both graphics functions
and the TFT ILI9341 driver library.

It is a "slow" version which shares the SPI bus politely with other devices.

It is written in plain C.
